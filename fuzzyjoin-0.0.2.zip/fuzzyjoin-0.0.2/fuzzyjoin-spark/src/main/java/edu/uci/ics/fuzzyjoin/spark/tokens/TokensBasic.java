package edu.uci.ics.fuzzyjoin.spark.tokens;

import java.io.IOException;

public class TokensBasic {
    public static void main(String[] args) throws IOException {
        // Phase 1
    }
}
