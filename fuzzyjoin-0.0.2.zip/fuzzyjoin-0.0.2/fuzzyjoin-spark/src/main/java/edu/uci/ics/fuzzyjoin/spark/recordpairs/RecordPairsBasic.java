package edu.uci.ics.fuzzyjoin.spark.recordpairs;

public class RecordPairsBasic {

}
