package edu.uci.ics.fuzzyjoin.spark.ridpairs;

public class RIDPairsPPJoin {

}
