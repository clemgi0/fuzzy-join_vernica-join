- Camera-ready version (PDF) of the accepted SIGMOD 2010 paper #146
  "Efficient Parallel Set-Similarity Joins Using MapReduce".

http://asterix.ics.uci.edu/pub/sigmod10-vernica.pdf

- Starting Datasets

DBLP (83MB, 1.2M records) 
http://asterix.ics.uci.edu/data/dblp.raw.txt.gz

CITESEERX (591MB, 1.3M records)
http://asterix.ics.uci.edu/data/csx.raw.txt.gz

- Instructions:

Please see fuzzyjoin-hadoop/resources/rwe/SIGMOD-2010-RWE.xml.
